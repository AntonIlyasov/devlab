void FTData();
void FT_Setup();
