GY-85 Arduino Library
=====================
A basic GY-85 raw data getter for arduino.

Wiring for arduino UNO:

GY-85   ->   Arduino  
--------------------  
VCC_IN  ->   5V  
GND     ->   GND  
SCL     ->   A5  
SDA     ->   A4  

For other arduino boards you have to check the I2C pins.

Installation
--------------------
Download library and move it to your Arduino/libraries folder